** October 19, 2006

** Made a few changes based on suggestions from Emerson Reed. Many thanks, Emerson!!!

Well, after going back and forth, trying to decide whether the AlertManager's NewAlert() method 
should return an Object Reference to the Alert or just the Alert's Name, I've decided on the 
original use of an object reference.
 
loAlert = oMgr.NewAlert()

Now, you can do either of the following to actually get the Alert to appear:

loAlert.Alert("Hey, this is my alert!") 

OR

lcName = loAlert.Name
oMgr.Alerts.Item(lcName).Alert("Hey, this is my alert!")

** Please see the PROGRAM1.PRG and PROGRAM2.PRG files (Demo from the Session)
** and FROMVFP6.PRG (A VFP6 Demo) for more info on using the system.

** Now, when the Alert's nResult_Assign method fires,
** the Alert will remove itself from the AlertManager's
** Alerts collection, then RELEASE itself.

** Rut-roh, Rorge... No more "fade-out"... 

Thanks to everyone who attended the session on Desktop Alerts at FoxForward!

The zipped files included in this file are:

DeskAlert.zip: The Whitepaper (MS Word) used for the session.
VFPAlertSC_20061019.zip: Complete source code and related files.

** For the source code, please note this should *not* be considered 'production code'!!! You know 
the drill, no warranties, you can't sue me, etc.

There's also no copyright, etc. It's yours, ALL YOURS, to do anything you want. Fix, enhance, 
improve, etc. 

Just do me a big 'ol favor. If you fix it, let me know what you did so I can fix mine, too! And, if
you have any questions, comments, etc, please feel free to contact me (contact info is below).

Time permitting, I'll put together an actual Help File.

Thanks again,

Kevin Ragsdale
kevin@pc-interactive.com
(931)570-2286
Skype: kevin.ragsdale
