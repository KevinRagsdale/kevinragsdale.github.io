Using the TransparentForm custom class

To use the class, simply drop it on a form, and
set the nOpaquePct property (default is 90).

Note: No effect will be seen in any versions of
Windows prior to Windows 2000, nor will any effect
be seen on a non-TopLevel form.

Any issues, problems, questions? Check my contact
information below.

Happy Foxing!

Kevin Ragsdale
kevin@pc-interactive.com
Skype: kevin.ragsdale