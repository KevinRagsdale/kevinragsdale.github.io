# SQLite ODBC Driver Setup Guide for Visual FoxPro

This guide provides step-by-step instructions for setting up Christian Werner's SQLite ODBC Driver to work with Visual FoxPro for bulk data operations.

## Prerequisites

### System Requirements
- Windows 7/8/10/11 (32-bit or 64-bit)
- Visual FoxPro 6.0 or later
- Administrator privileges for ODBC driver installation

### Required Software
1. **Visual FoxPro** - Any version 6.0 or later
2. **SQLite ODBC Driver** - Christian Werner's driver from https://www.ch-werner.de/sqliteodbc/

## Installation Steps

### Step 1: Download SQLite ODBC Driver

1. Visit https://www.ch-werner.de/sqliteodbc/
2. Download the appropriate version:
   - **32-bit**: For 32-bit Visual FoxPro
   - **64-bit**: For 64-bit Visual FoxPro (if available)
3. Choose the latest stable version

### Step 2: Install the ODBC Driver

1. **Run the installer as Administrator**
   - Right-click the downloaded installer
   - Select "Run as administrator"

2. **Follow the installation wizard**
   - Accept the license agreement
   - Choose installation directory (default is fine)
   - Complete the installation

3. **Verify installation**
   - The driver should be registered in your system's ODBC Data Source Administrator

### Step 3: Configure ODBC Data Source

1. **Open ODBC Data Source Administrator**
   - Press `Win + R`
   - Type `odbcad32.exe` and press Enter
   - **Important**: Use the correct version (32-bit or 64-bit) matching your VFP

2. **Create System DSN**
   - Go to "System DSN" tab
   - Click "Add"
   - Select "SQLite3 ODBC Driver" from the list
   - Click "Finish"

3. **Configure the Data Source**
   - **Data Source Name**: `SQLiteDB` (or your preferred name)
   - **Database**: Browse to your SQLite database file
   - **Version**: SQLite3
   - **Timeout**: 30 (or as needed)
   - **Additional Options**:
     - **Read Only**: Unchecked (for write operations)
     - **Load Extensions**: Checked (if needed)
     - **Foreign Keys**: Checked (for referential integrity)

4. **Test the connection**
   - Click "Test" to verify the connection works
   - Click "OK" to save

### Step 4: Verify Installation in Visual FoxPro

1. **Open Visual FoxPro**

2. **Test the connection**:
   ```foxpro
   * Test basic connection
   lnHandle = SQLCONNECT("SQLiteDB")
   IF lnHandle > 0
       ? "Connection successful!"
       SQLDISCONNECT(lnHandle)
   ELSE
       ? "Connection failed!"
   ENDIF
   ```

3. **Test a simple query**:
   ```foxpro
   lnHandle = SQLCONNECT("SQLiteDB")
   IF lnHandle > 0
       lnResult = SQLEXEC(lnHandle, "SELECT 1 as test")
       IF lnResult > 0
           ? "Query execution successful!"
       ENDIF
       SQLDISCONNECT(lnHandle)
   ENDIF
   ```

## Configuration Options

### ODBC Driver Settings

| Setting | Description | Recommended Value |
|---------|-------------|-------------------|
| **Database** | Path to SQLite database file | Full path to your .db file |
| **Version** | SQLite version | SQLite3 |
| **Timeout** | Connection timeout in seconds | 30 |
| **Read Only** | Read-only mode | Unchecked (for writes) |
| **Load Extensions** | Enable SQLite extensions | Checked |
| **Foreign Keys** | Enable foreign key constraints | Checked |

### Performance Settings

| Setting | Description | Recommended Value |
|---------|-------------|-------------------|
| **Batch Size** | Records per batch insert | 1000-5000 |
| **Use Transactions** | Enable transaction support | Yes |
| **Show Progress** | Display progress indicators | Yes |
| **Error Level** | Error reporting detail | 2 (Detailed) |

## Troubleshooting

### Common Issues

#### 1. "Driver Not Found" Error
**Symptoms**: Cannot find SQLite3 ODBC Driver in DSN list
**Solutions**:
- Ensure you installed the correct bitness (32/64-bit)
- Reinstall the driver as Administrator
- Check if driver appears in ODBC Data Source Administrator

#### 2. "Connection Failed" Error
**Symptoms**: SQLCONNECT returns negative value
**Solutions**:
- Verify database file path is correct
- Check file permissions
- Ensure database file exists
- Try using absolute path

#### 3. "Permission Denied" Error
**Symptoms**: Cannot write to database
**Solutions**:
- Check file permissions on database file
- Ensure database directory is writable
- Run Visual FoxPro as Administrator if needed

#### 4. Performance Issues
**Symptoms**: Slow transfer speeds
**Solutions**:
- Increase batch size (1000-5000 records)
- Disable indexes during bulk load
- Use transactions
- Ensure adequate system memory

### Diagnostic Commands

```foxpro
* Test connection
DO SQLITE_UTILS.PRG
TestSQLiteConnection("SQLiteDB")

* List available tables
ListSQLiteTables("SQLiteDB")

* Check record count
lnCount = GetSQLiteRecordCount("YourTable", "SQLiteDB")
? "Records: " + ALLTRIM(STR(lnCount))
```

## Best Practices

### Performance Optimization

1. **Batch Size**: Use larger batch sizes (1000-5000) for better performance
2. **Transactions**: Always use transactions for bulk operations
3. **Indexes**: Disable indexes during bulk load, recreate after
4. **Memory**: Ensure adequate system memory for large transfers

### Data Integrity

1. **Backup**: Always backup your SQLite database before bulk operations
2. **Validation**: Verify record counts after transfer
3. **Error Handling**: Use proper error handling and logging
4. **Testing**: Test with small datasets first

### Maintenance

1. **VACUUM**: Run VACUUM after large operations to optimize database
2. **ANALYZE**: Run ANALYZE to update statistics
3. **Logging**: Monitor log files for errors and performance metrics

## Support Resources

- **SQLite ODBC Driver**: https://www.ch-werner.de/sqliteodbc/
- **SQLite Documentation**: https://www.sqlite.org/docs.html
- **Visual FoxPro ODBC**: Microsoft Visual FoxPro documentation

## Next Steps

After completing the setup:

1. **Test the basic transfer**:
   ```foxpro
   DO EXAMPLES/EXAMPLE_1_BASIC_TRANSFER.PRG
   ```

2. **Configure your settings**:
   ```foxpro
   DO CONFIG.PRG
   DO InitConfig()
   ShowConfig()
   ```

3. **Run performance tests**:
   ```foxpro
   DO EXAMPLES/EXAMPLE_2_ADVANCED_TRANSFER.PRG
   ```

4. **Transfer your data**:
   ```foxpro
   DO VFP_TO_SQLITE_BULK.PRG WITH "YourTable", "YourSQLiteTable"
   ``` 