# Visual FoxPro to SQLite Bulk Data Transfer

This project provides a solution for efficiently transferring data from Visual FoxPro tables to SQLite databases using Christian Werner's SQLite ODBC Driver.

## Prerequisites

1. **Visual FoxPro** (any version 6.0 or later)
2. **Christian Werner's SQLite ODBC Driver** - Download from: https://www.ch-werner.de/sqliteodbc/
3. **SQLite Database** (target database)

## Installation

### 1. Install SQLite ODBC Driver
1. Download the appropriate version for your system (32-bit or 64-bit)
2. Run the installer
3. The driver will be registered in your system's ODBC Data Source Administrator

### 2. Configure ODBC Data Source
1. Open "ODBC Data Source Administrator" (32-bit or 64-bit as needed)
2. Go to "System DSN" tab
3. Click "Add" and select "SQLite3 ODBC Driver"
4. Configure your data source:
   - **Data Source Name**: YourSQLiteDB
   - **Database**: Path to your SQLite database file
   - **Version**: SQLite3
   - **Timeout**: 30 (or as needed)

## Usage

### Basic Bulk Transfer
```foxpro
* Run the bulk transfer program
DO VFP_TO_SQLITE_BULK.PRG WITH "YourTableName", "YourSQLiteTable"
```

### Advanced Configuration
```foxpro
* With custom options
DO VFP_TO_SQLITE_BULK.PRG WITH "SourceTable", "TargetTable", "YourDSN", 1000
```

## Features

- **Bulk Insert Operations**: Transfer thousands of records efficiently
- **Batch Processing**: Configurable batch sizes for optimal performance
- **Error Handling**: Comprehensive error reporting and recovery
- **Progress Tracking**: Real-time progress indicators
- **Data Type Mapping**: Automatic VFP to SQLite data type conversion
- **Transaction Support**: ACID compliance with rollback capability

## Performance Tips

1. **Batch Size**: Use larger batch sizes (1000-5000) for better performance
2. **Indexes**: Disable indexes during bulk load, recreate after
3. **Transactions**: Use transactions for better performance and data integrity
4. **Memory**: Ensure adequate memory for large transfers

## File Structure

- `VFP_TO_SQLITE_BULK.PRG` - Main bulk transfer program
- `SQLITE_UTILS.PRG` - Utility functions for SQLite operations
- `CONFIG.PRG` - Configuration settings
- `EXAMPLES/` - Example usage scenarios
- `DOCS/` - Detailed documentation

## Troubleshooting

### Common Issues

1. **ODBC Driver Not Found**
   - Ensure correct bitness (32/64-bit) matches your VFP version
   - Verify driver installation in ODBC Data Source Administrator

2. **Performance Issues**
   - Increase batch size
   - Disable indexes during transfer
   - Use transactions

3. **Data Type Conversion Errors**
   - Check data type mapping in SQLITE_UTILS.PRG
   - Validate source data before transfer

## Support

For issues with the SQLite ODBC Driver itself, visit: https://www.ch-werner.de/sqliteodbc/

## License

This project is provided as-is for educational and development purposes. 