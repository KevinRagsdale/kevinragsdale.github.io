This code is presented as-is, and without warranty of any kind.

USE AT YOUR OWN RISK!

You may use and distribute this code in way you want, provided:

	* You cannot sue me for any damages resulting from the use of this code
	  (I've been sued enough times for one lifetime)

In order to use this code, you will need the West-Wind Internet Protocols. You can download a shareware version at:

http://www.west-wind.com/files/wwClient.zip

The files in this download are:

GDOCS.PRG: A Visual FoxPro Program file, demonstrating how to access the Google Docs API with VFP
MAIN.PRG: The Desktop Alerts "main" program file (used in one of the examples)
GDOCS.DOC: A Word document used in one of the examples.


Thanks, and Enjoy!

Kevin Ragsdale

